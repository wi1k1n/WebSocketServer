﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Collections.Generic;
using System.Text;
using OrbitalServer2.Service;

namespace OrbitalServer2.Server
{
    delegate void WSStrReceivedEventHandler (object sender, WSStrMsgEventArgs e);
    delegate void WSBinReceivedEventHandler (object sender, WSBinMsgEventArgs e);
    delegate void WSClientConnectedEventHandler (object sender, WSClientEventArgs e);
    delegate void WSHandShakeSuccessEventHandler (object sender, WSClientEventArgs e);
    delegate void WSHandShakeFailEventHandler (object sender, WSClientQuitEventArgs e);
    delegate void WSClientQuitEventHandler (object sender, WSClientQuitEventArgs e);

    class WSServer
    {
        public event WSClientConnectedEventHandler OnClientConnected;
        public event WSHandShakeSuccessEventHandler OnHandShakeSuccess;
        public event WSStrReceivedEventHandler OnStringReceived;
        public event WSBinReceivedEventHandler OnBinaryReceived;
        public event WSClientQuitEventHandler OnClientQuit;

        private TcpListener listener;
        private bool isRunning;
        private List<WSClient> clientList;
        private int uidCnt = 1;

        public int Port { get; private set; }
        public bool IsRunning { get { return isRunning; } }
        public List<WSClient> ClientList { get { return clientList; } }
        public WSTraffic Traffic
        {
            get
            {
                WSTraffic tr = new WSTraffic();
                foreach (WSClient cl in clientList)
                    tr.AddTraffic(cl.Traffic);
                return tr;
            }
        }

        public WSServer (int port)
        {
            // Записываем порт и создаем слушателя порта
            Port = port;
            listener = new TcpListener(IPAddress.Any, Port);
            isRunning = false;
            clientList = new List<WSClient>();
        }

        public void Start ()
        {
            // Запускаем слушателя и в бесконечном цикле принимаем клиентов
            listener.Start();
            isRunning = true;
            while (isRunning)
            {
                // Для каждого клиента запускаем отдельный поток, где анонимной функцией создаем новый экземпляр клиента
                TcpClient client = listener.AcceptTcpClient();
                Thread thread = new Thread(delegate(object obj)
                {
                    WSClient newClient = new WSClient((TcpClient)obj, uidCnt++);
                    newClient.OnPacketReceived += newClient_OnPacketReceived;
                    newClient.OnHandShakeSuccess += newClient_OnHandShakeSuccess;
                    clientList.Add(newClient);
                    onClientConnected(newClient.UID);
                    newClient.Start();
                });
                thread.Start(client);
            }
        }

        void newClient_OnHandShakeSuccess (object sender, WSClientEventArgs e)
        {
            onHandShakeSuccess(e.UID);
        }

        void newClient_OnPacketReceived (object sender, WSPacketEventArgs e)
        {
            if (e.Packets.LastPacket.Opcode == 1)
                onStringReceived(ByteManager.byteArrayToString(e.Packets.LastPacket.Data), e.UID);
            else if (e.Packets.LastPacket.Opcode == 2)
                onBinaryReceived(e.Packets.LastPacket.Data, e.UID);
            else if (e.Packets.LastPacket.Opcode == 8)
                onClientQuit(e.UID, ByteManager.Int16FromBytes(e.Packets.LastPacket.Data[0], e.Packets.LastPacket.Data[1]));
        }

        private void onStringReceived (string msg, int uid)
        {
            if (OnStringReceived != null)
                OnStringReceived(this, new WSStrMsgEventArgs(msg, uid));
        }
        private void onBinaryReceived (byte[] data, int uid)
        {
            if (OnBinaryReceived != null)
                OnBinaryReceived(this, new WSBinMsgEventArgs(data, uid));
        }
        private void onClientConnected (int uid)
        {
            if (OnClientConnected != null)
                OnClientConnected(this, new WSClientEventArgs(uid));
        }
        private void onHandShakeSuccess (int uid)
        {
            if (OnHandShakeSuccess != null)
                OnHandShakeSuccess(this, new WSClientEventArgs(uid));
        }
        private void onClientQuit (int uid, int code)
        {
            if (OnClientQuit != null)
                OnClientQuit(this, new WSClientQuitEventArgs(uid, code));
            WSClient client = getClientByUID(uid);
            try
            {
                client.Stop();
            } catch { }
            clientList.Remove(client);
        }

        // Остановка всего сервера
        public void Stop ()
        {
            //TODO: Аккуратный стоп сервера
        }

        #region Методы Взаимодействия Сервера с Клиентами
        public void Broadcast (string msg)
        {
            Broadcast(msg, -1);
        }
        public void Broadcast (string msg, int uid)
        {
            foreach(WSClient cl in clientList)
                if (cl.UID != uid)
                    cl.SendString(msg);
        }
        public bool Send (byte[] data, int uid)
        {
            WSClient client = getClientByUID(uid);
            if (client == null) return false;
            if (client.AvailableToTransmit)
                client.SendBinary(data);
            return true;
        }
        public bool Send (string msg, int uid)
        {
            WSClient client = getClientByUID(uid);
            if (client == null) return false;
            if (client.AvailableToTransmit)
                client.SendString(msg);
            return true;
        }
        public bool Send (byte b, int uid)
        {
            return Send(new byte[] { b }, uid);
        }
        // Закрытие соединения, вызванное пользователем
        public bool Close (int uid)
        {
            WSClient client = getClientByUID(uid);
            if (client == null) return false;
            client.Stop();
            clientList.Remove(client);
            return true;
        }
        public void CloseAll ()
        {
            int len = clientList.Count;
            for (int i = 0; i < len; i++)
            {
                clientList[0].Stop();
                clientList.Remove(clientList[0]);
            }
        }
        #endregion

        private WSClient getClientByUID (int uid)
        {
            foreach (WSClient client in clientList)
                if (client.UID == uid)
                    return client;
            return null;
        }
    }

    class WSStrMsgEventArgs
    {
        public string Msg { get; private set; }
        public int UID { get; private set; }

        public WSStrMsgEventArgs (string msg, int uid)
        {
            UID = uid;
            Msg = msg;
        }
    }
    class WSBinMsgEventArgs
    {
        public byte[] Data { get; private set; }
        public int UID { get; private set; }

        public WSBinMsgEventArgs (byte[] data, int uid)
        {
            UID = uid;
            Data = data;
        }
    }
    class WSClientEventArgs
    {
        public int UID { get; private set; }

        public WSClientEventArgs (int uid)
        {
            UID = uid;
        }
    }
    class WSClientQuitEventArgs
    {
        public int UID { get; private set; }
        public int Code { get; private set; }

        public WSClientQuitEventArgs (int uid, int code)
        {
            UID = uid;
            Code = code;
        }
    }
}
