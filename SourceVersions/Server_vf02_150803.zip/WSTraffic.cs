﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OrbitalServer2.Server
{
    class WSTraffic
    {
        public UInt64 TrafficReceived { get; private set; }
        public UInt64 TrafficSent { get; private set; }
        public UInt64 TrafficAll { get { return TrafficReceived + TrafficSent; } }

        public WSTraffic ()
        {
            TrafficReceived = 0;
            TrafficSent = 0;
        }

        public void AddTrafficReceived (UInt64 traffic)
        {
            TrafficReceived += traffic;
        }
        public void AddTrafficReceived (Int64 traffic)
        {
            AddTrafficReceived((UInt64)traffic);
        }
        public void AddTrafficSent (UInt64 traffic)
        {
            TrafficSent += traffic;
        }
        public void AddTrafficSent (Int64 traffic)
        {
            AddTrafficSent((UInt64)traffic);
        }
        public void AddTraffic (WSTraffic tr)
        {
            AddTrafficReceived(tr.TrafficReceived);
            AddTrafficSent(tr.TrafficSent);
        }
    }
}
