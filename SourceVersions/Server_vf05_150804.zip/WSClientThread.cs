﻿using System;
using System.Threading;

namespace WebSocketServer
{
    class WSClientThread
    {
        public WSClient Client { get; set; }
        public Thread Thread { get; set; }
        public WSClientThread (WSClient client, Thread thread)
        {
            Client = client;
            Thread = thread;
        }
    }
}
