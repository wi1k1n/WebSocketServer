﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Collections.Generic;
using System.Text;
using WebSocketServer.Service;

namespace WebSocketServer
{
    delegate void WSStrReceivedEventHandler (object sender, WSStrMsgEventArgs e);
    delegate void WSBinReceivedEventHandler (object sender, WSBinMsgEventArgs e);
    delegate void WSClientConnectedEventHandler (object sender, WSClientEventArgs e);
    delegate void WSHandShakeSuccessEventHandler (object sender, WSClientEventArgs e);
    delegate void WSHandShakeFailEventHandler (object sender, WSClientQuitEventArgs e);
    delegate void WSClientQuitEventHandler (object sender, WSClientQuitEventArgs e);
    delegate void WSClientClosedEventHandler (object sender, WSClientEventArgs e);

    class WSServer
    {
        public event WSClientConnectedEventHandler OnClientConnected;
        public event WSHandShakeSuccessEventHandler OnHandShakeSuccess;
        public event WSStrReceivedEventHandler OnStringReceived;
        public event WSBinReceivedEventHandler OnBinaryReceived;
        public event WSClientQuitEventHandler OnClientQuit;
        public event WSClientClosedEventHandler OnClientClosed;

        private TcpListener listener;
        private List<WSClientThread> clients;
        private int uidCnt = 1;

        public int Port { get; private set; }
        public bool IsRunning { get; private set; }
        public WSTraffic Traffic
        {
            get
            {
                WSTraffic tr = new WSTraffic();
                foreach (WSClientThread cl in clients)
                    tr.AddTraffic(cl.Client.Traffic);
                return tr;
            }
        }

        public WSServer (int port)
        {
            // Записываем порт и создаем слушателя порта
            Port = port;
            listener = new TcpListener(IPAddress.Any, Port);
            IsRunning = false;
            clients = new List<WSClientThread>();
        }

        public void Start ()
        {
            // Запускаем слушателя и в бесконечном цикле принимаем клиентов
            listener.Start();
            IsRunning = true;
            while (IsRunning)
            {
                try // Когда сервер останавливается, listener.AcceptTcpClient() выдает эксепшн заблокированного потока
                {
                    // Для каждого клиента запускаем отдельный поток, где анонимной функцией создаем новый экземпляр клиента
                    TcpClient client = listener.AcceptTcpClient();
                    WSClient nclient = new WSClient(client, uidCnt++);
                    nclient.OnPacketReceived += newClient_OnPacketReceived;
                    nclient.OnHandShakeSuccess += newClient_OnHandShakeSuccess;
                    nclient.OnConnectionClosed += newClient_OnConnectionClosed;
                    onClientConnected(nclient.UID);
                    Thread thread = new Thread(delegate(object obj) { ((WSClient)obj).Start(); });
                    clients.Add(new WSClientThread(nclient, thread));
                    thread.Start(nclient);
                } catch { }
            }
        }

        void newClient_OnConnectionClosed (object sender, WSClientQuitEventArgs e)
        {
            onClientQuit(e.UID, e.Code);
        }

        void newClient_OnHandShakeSuccess (object sender, WSClientEventArgs e)
        {
            onHandShakeSuccess(e.UID);
        }

        void newClient_OnPacketReceived (object sender, WSPacketEventArgs e)
        {
            if (e.Packets.LastPacket.Opcode == 1)
                onStringReceived(ByteManager.byteArrayToString(e.Packets.LastPacket.Data), e.UID);
            else if (e.Packets.LastPacket.Opcode == 2)
                onBinaryReceived(e.Packets.LastPacket.Data, e.UID);
            else if (e.Packets.LastPacket.Opcode == 8)
                if (e.Packets.LastPacket.Data.Length == 2)
                    onClientQuit(e.UID, ByteManager.Int16FromBytes(e.Packets.LastPacket.Data[0], e.Packets.LastPacket.Data[1]));
                else
                    onClientQuit(e.UID, 1000);
            // Opcode == 8, не до конца понятен вопрос с кодом 1000, когда data = new byte[0];
        }

        #region Event Methods
        private void onStringReceived (string msg, int uid)
        {
            if (OnStringReceived == null) return;
            OnStringReceived(this, new WSStrMsgEventArgs(msg, uid));
        }
        private void onBinaryReceived (byte[] data, int uid)
        {
            if (OnBinaryReceived == null) return;
            OnBinaryReceived(this, new WSBinMsgEventArgs(data, uid));
        }
        private void onClientConnected (int uid)
        {
            if (OnClientConnected == null) return;
            OnClientConnected(this, new WSClientEventArgs(uid));
        }
        private void onHandShakeSuccess (int uid)
        {
            if (OnHandShakeSuccess == null) return;
            OnHandShakeSuccess(this, new WSClientEventArgs(uid));
        }
        private void onClientQuit (int uid, int code)
        {
            // TODO: разобраться с порядком (событие, метод || метод, событие)
            if (OnClientQuit != null)
            {
                OnClientQuit(this, new WSClientQuitEventArgs(uid, code));
            }
            Close(uid);
        }
        // Вызывается, в отличие от onClientQuit, при принудительном закрытии сервером соединения с клиентом
        private void onClientClosed (int uid)
        {
            // TODO: разобраться с порядком (событие, метод || метод, событие)
            if (OnClientClosed != null)
            {
                OnClientClosed(this, new WSClientEventArgs(uid));
            }
        }
        #endregion

        // Остановка всего сервера
        public void Stop ()
        {
            foreach(WSClientThread client in clients)
                try
                {
                    client.Client.Stop();
                    client.Thread.Abort();
                } catch { }
            IsRunning = false;
            clients.Clear();
            listener.Stop();
        }

        #region Методы Взаимодействия Сервера с Клиентами
        public void Broadcast (string msg)
        {
            // Не используется вызов Broadcast (msg, uid), т.к. в случае данного метода там присутствует лишний if
            foreach (WSClientThread cl in clients)
                cl.Client.SendString(msg);
        }
        // uid - UID клиента, которому не будет осуществлена передача (чисто чатный метод)
        public void Broadcast (string msg, int uid)
        {
            foreach(WSClientThread cl in clients)
                if (cl.Client.UID != uid)
                    cl.Client.SendString(msg);
        }
        public bool Send (byte[] data, int uid)
        {
            WSClient client = getClientByUID(uid);
            if (client == null) return false;
            if (client.AvailableToTransmit)
                client.SendBinary(data);
            return true;
        }
        public bool Send (string msg, int uid)
        {
            WSClient client = getClientByUID(uid);
            if (client == null) return false;
            if (client.AvailableToTransmit)
                client.SendString(msg);
            return true;
        }
        public bool Send (byte b, int uid)
        {
            return Send(new byte[] { b }, uid);
        }
        // Закрытие соединения, вызванное пользователем
        public bool Close (int uid)
        {
            // TODO: разобраться с try/catch
            WSClientThread client = getClientThreadByUID(uid);
            if (client == null) return false;
            try
            {
                client.Client.Stop();
                client.Thread.Abort();
                clients.Remove(client);
                onClientClosed(uid);
            } catch { }
            return true;
        }
        public void CloseAll ()
        {
            // TODO: разобраться с try/catch
            int len = clients.Count;
            int uid = -1;
            for (int i = 0; i < len; i++)
            {
                uid = clients[0].Client.UID;
                try
                {
                    clients[0].Client.Stop();
                    clients[0].Thread.Abort();
                    clients.Remove(clients[0]);
                    onClientClosed(uid);
                } catch { }
            }
        }
        #endregion

        private WSClient getClientByUID (int uid)
        {
            return getClientThreadByUID(uid).Client;
        }
        private WSClientThread getClientThreadByUID (int uid)
        {
            foreach (WSClientThread client in clients)
                if (client.Client.UID == uid)
                    return client;
            return null;
        }
    }

    class WSStrMsgEventArgs
    {
        public string Msg { get; private set; }
        public int UID { get; private set; }

        public WSStrMsgEventArgs (string msg, int uid)
        {
            UID = uid;
            Msg = msg;
        }
    }
    class WSBinMsgEventArgs
    {
        public byte[] Data { get; private set; }
        public int UID { get; private set; }

        public WSBinMsgEventArgs (byte[] data, int uid)
        {
            UID = uid;
            Data = data;
        }
    }
    class WSClientEventArgs
    {
        public int UID { get; private set; }

        public WSClientEventArgs (int uid)
        {
            UID = uid;
        }
    }
    class WSClientQuitEventArgs
    {
        public int UID { get; private set; }
        public int Code { get; private set; }

        public WSClientQuitEventArgs (int uid, int code)
        {
            UID = uid;
            Code = code;
        }
    }
}
