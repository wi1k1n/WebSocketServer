﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WebSocketServer
{
    class WSTraffic
    {
        public UInt64 TrafficReceived { get; private set; }
        public UInt64 TrafficSent { get; private set; }
        public UInt64 TrafficAll { get { return TrafficReceived + TrafficSent; } }

        public WSTraffic () : this(0, 0) { }
        public WSTraffic (UInt64 received, UInt64 sent)
        {
            TrafficReceived = 0;
            TrafficSent = 0;
        }
        public WSTraffic (WSTraffic tr)
        {
            TrafficReceived = tr.TrafficReceived;
            TrafficSent = tr.TrafficSent;
        }

        public void AddTrafficReceived (UInt64 traffic)
        {
            TrafficReceived += traffic;
        }
        public void AddTrafficReceived (Int64 traffic)
        {
            AddTrafficReceived((UInt64)traffic);
        }
        public void AddTrafficSent (UInt64 traffic)
        {
            TrafficSent += traffic;
        }
        public void AddTrafficSent (Int64 traffic)
        {
            AddTrafficSent((UInt64)traffic);
        }
        public void AddTraffic (WSTraffic tr)
        {
            AddTrafficReceived(tr.TrafficReceived);
            AddTrafficSent(tr.TrafficSent);
        }

        public static WSTraffic operator + (WSTraffic tr1, WSTraffic tr2)
        {
            WSTraffic tres = new WSTraffic(tr1);
            tres.AddTraffic(tr2);
            return tres;
        }
    }
}
